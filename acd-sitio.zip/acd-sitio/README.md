# A.C.D. · Agencia de Contenciones Dimensionales

Sitio estático (HTML, CSS y JS). El contenido vive en archivos de datos, así que cualquiera que abra el sitio ve los cambios que subas al repositorio.

## Estructura
```
index.html            Estructura de la página y cargador
css/style.css         Estilos
js/app.js             Lógica del sitio
js/github.js          Publicación a GitHub y sincronización automática
data/db.json          Terminales, partes, entidades, microdimensiones, objetos y armas
data/terminales/      Un .txt por terminal (cap_01.txt, cap_07.txt...)
data/users.json       Cuentas y niveles (claves en SHA-256)
data/lore.txt         Texto del Archivo D-345
assets/img/...        Imágenes propias (creatures, dims, objects, weapons)
```

## Publicar en GitHub Pages
1. Sube todo el contenido de esta carpeta a un repositorio.
2. En Settings → Pages, elige la rama `main` y la carpeta `/ (root)`.
3. Abre la URL que te da GitHub. No funciona con doble clic en `index.html`: necesita un servidor (GitHub Pages o `python3 -m http.server`).

## Añadir contenido
**Desde el sitio (recomendado):** entra como ZERO, crea la terminal, entidad, objeto, arma o microdimensión, ve a PUBLICAR, guarda tus ajustes de GitHub (usuario, repositorio, rama y un token con permiso *Contents: Read and write* solo para este repo) y pulsa PUBLICAR CAMBIOS. Sube solo las imágenes y textos nuevos y actualiza `data/db.json`.

**A mano:** 
- Terminal: crea `data/terminales/cap_07.txt` y añade en `chaps` de `db.json`: `{"id":"c7","n":7,"title":"Título","part":"p2","file":"data/terminales/cap_07.txt"}`. Se ordena sola por `n`.
- Imagen: guarda el archivo en `assets/img/creatures/ACD-001.jpg` y pon `"img":"assets/img/creatures/ACD-001.jpg"` en esa entidad.

## Cuentas
Se definen en `data/users.json` como hash SHA-256. Para generar uno: `printf 'miclave' | sha256sum`. El campo `l` es el nivel (0 a 5; 9 es el admin, con `"r":"admin"`).

## Aviso de seguridad
Las claves se comprueban en el navegador, así que sirven como puerta de entrada narrativa, no como protección real. El contenido de `data/` es público en el repositorio.
