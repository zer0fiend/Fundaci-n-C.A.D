/* Publicación a GitHub y sincronización de contenido. Se carga después de app.js */
let LASTDB=window.__DBT;
const GF={cre:'creatures',dims:'dims',obj:'objects',wpn:'weapons'};
const b64=s=>btoa(unescape(encodeURIComponent(s)));
const GHC=()=>{try{return JSON.parse(localStorage.getItem('acd_gh'))||{}}catch(e){return{}}};

async function sync(){
  try{
    const t=await fetch('data/db.json?t='+Date.now(),{cache:'no-store'}).then(r=>r.text());
    if(t===LASTDB)return;
    LASTDB=t;window.__DBT=t;
    let draft=null;try{draft=role==='admin'&&localStorage.getItem('acd_draft')}catch(e){}
    if(draft)return;
    DB=JSON.parse(t);
    if(role){toast('ARCHIVOS ACTUALIZADOS');if(['t','p','b','d','o','w'].includes(CUR)&&!document.querySelector('#view .dos'))show(CUR)}
  }catch(e){}
}
setInterval(sync,60000);

async function ghPut(c,path,content,msg){
  const u=`https://api.github.com/repos/${c.o}/${c.r}/contents/${path}`;
  const h={Authorization:'Bearer '+c.t,Accept:'application/vnd.github+json'};
  let sha;const g=await fetch(u+'?ref='+encodeURIComponent(c.b),{headers:h});
  if(g.ok)sha=(await g.json()).sha;
  const r=await fetch(u,{method:'PUT',headers:h,body:JSON.stringify({message:msg,content,branch:c.b,sha})});
  if(!r.ok)throw new Error(path+' → error '+r.status);
}

async function publish(log){
  const c=GHC();if(!c.o||!c.r||!c.t)throw new Error('Faltan los ajustes de GitHub');
  c.b=c.b||'main';
  const out=JSON.parse(JSON.stringify(DB));delete out.om5;
  for(const k in GF){for(const it of out[k]||[]){
    if(it.img&&it.img.startsWith('data:')){
      const p=`assets/img/${GF[k]}/${it.id.replace(/[^A-Za-z0-9_-]/g,'_')}.jpg`;
      log('subiendo '+p);await ghPut(c,p,it.img.split(',')[1],'imagen '+it.id);it.img=p}}}
  for(const ch of out.chaps){
    if(ch.text!=null&&!ch.file){const p=`data/terminales/cap_${pad(ch.n)}.txt`;log('subiendo '+p);await ghPut(c,p,b64(ch.text),'terminal '+ch.n);ch.file=p}
    delete ch.text}
  log('subiendo data/db.json');
  await ghPut(c,'data/db.json',b64(JSON.stringify(out,null,1)),'actualizar contenido');
  try{localStorage.removeItem('acd_draft')}catch(e){}
}

function publicar(){
  if(role!=='admin')return;const c=GHC();
  V(`<h2 class='gl' data-t='PUBLICAR' style='font-size:42px'>PUBLICAR</h2>
<p style='color:var(--gd);max-width:70ch'>Sube tus cambios al repositorio de GitHub. Todos los visitantes los ven cuando GitHub Pages termina de actualizar (cerca de 1 minuto) y el sitio se refresca solo cada 60 segundos.</p>
<div class='panel'><div class='row'><div><label>USUARIO U ORGANIZACIÓN</label><input id='gu' value='${esc(c.o||'')}'></div><div><label>REPOSITORIO</label><input id='gr' value='${esc(c.r||'')}'></div><div><label>RAMA</label><input id='gb' value='${esc(c.b||'main')}'></div></div>
<label>TOKEN DE GITHUB (permiso Contents: lectura y escritura, solo este repositorio)</label><input id='gt' type='password' value='${esc(c.t||'')}'>
<p style='color:var(--gd);font-size:13px'>El token se guarda solo en este navegador. No lo compartas.</p><button id='gs'>GUARDAR AJUSTES</button></div>
<div class='panel'><div class='row'><button id='gp'>PUBLICAR CAMBIOS</button><button id='gx'>DESCARGAR db.json</button><button id='gd' class='danger'>DESCARTAR BORRADOR</button></div><div id='gl' style='white-space:pre-wrap;margin-top:12px;color:var(--gd)'></div></div>`);
  const L=t=>{$('#gl').textContent+=t+'\n'};
  $('#gs').onclick=()=>{try{localStorage.setItem('acd_gh',JSON.stringify({o:$('#gu').value.trim(),r:$('#gr').value.trim(),b:$('#gb').value.trim()||'main',t:$('#gt').value.trim()}))}catch(e){}$('#gs').textContent='GUARDADO'};
  $('#gp').onclick=async()=>{$('#gs').click();$('#gl').textContent='';try{await publish(L);L('LISTO. GitHub Pages tardará cerca de 1 minuto en mostrar los cambios.')}catch(e){L('ERROR: '+e.message)}};
  $('#gx').onclick=()=>{const o=JSON.parse(JSON.stringify(DB));delete o.om5;o.chaps.forEach(ch=>{if(ch.file)delete ch.text});const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([JSON.stringify(o,null,1)],{type:'application/json'}));a.download='db.json';a.click()};
  $('#gd').onclick=()=>{if(confirm('¿Descartar el borrador local y volver al contenido publicado?')){try{localStorage.removeItem('acd_draft')}catch(e){}DB=JSON.parse(window.__DBT);L('Borrador descartado.')}};
}
